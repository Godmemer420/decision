from PIL import Image

cards = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "j", "q", "k"]
ranks = ["c", "d", "h", "s"]
for c in cards:
    for r in ranks:
        name = r+c
        dest = 'C:\\Users\\giolf\\Desktop\\bj cards\\game\\' + name + ".png"

        picture = Image.open(dest)

        # Get the size of the image
        width, height = picture.size

        # Process every pixel
        toChange = (255, 0, 0, 255)
        changeTo = (128, 128, 128, 255)
        for x in range(width):
           for y in range(height):
                current_color = picture.getpixel( (x,y) )


                if current_color == toChange or current_color == (0, 0, 128, 255):
                   picture.putpixel((x, y), changeTo)


        file_name = name + '.jpg'
        picture.save(fp=file_name)