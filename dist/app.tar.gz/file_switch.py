cards = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "j", "q", "k"]
ranks = ["s"]
import os


for c in cards:
    for r in ranks:
        name = r+c
        dest = 'C:\\Users\\giolf\\Desktop\\bj cards\\game\\' + name + ".png"
        new = 'C:\\Users\\giolf\\Desktop\\bj cards\\game\\' + name + ".jpg"
        os.rename(dest, new)